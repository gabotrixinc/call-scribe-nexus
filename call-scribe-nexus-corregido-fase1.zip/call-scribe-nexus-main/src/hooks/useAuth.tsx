
// Re-exportar el hook de autenticación desde el directorio auth
export { useAuth } from './auth/useAuth';
