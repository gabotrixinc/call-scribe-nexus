// Función Edge para transcripción de audio en tiempo real con Gemini
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Parse request body
    const body = await req.json();
    const { audio_base64, call_id } = body;
    
    if (!audio_base64) {
      throw new Error('Se requiere audio en formato base64');
    }
    
    // Verificar API key de Gemini
    const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
    if (!geminiApiKey) {
      throw new Error('API key de Gemini no configurada');
    }
    
    console.log(`Procesando audio para transcripción, call_id: ${call_id}`);
    
    // Convertir base64 a blob para enviar a Gemini
    const binaryAudio = Uint8Array.from(atob(audio_base64), c => c.charCodeAt(0));
    
    // Crear FormData para enviar a Gemini
    const formData = new FormData();
    formData.append('audio', new Blob([binaryAudio], { type: 'audio/webm' }));
    
    // Configurar parámetros para la API de Gemini
    const params = new URLSearchParams({
      key: geminiApiKey,
    });
    
    // Realizar solicitud a la API de Gemini para STT
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?${params.toString()}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: "Transcribe el siguiente audio a texto. Responde solo con la transcripción, sin comentarios adicionales."
              },
              {
                inline_data: {
                  mime_type: "audio/webm",
                  data: audio_base64
                }
              }
            ]
          }
        ],
        generation_config: {
          temperature: 0.2,
          top_p: 0.8,
          top_k: 40
        }
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error('Error en respuesta de Gemini:', errorData);
      throw new Error(`Error de Gemini: ${errorData.error?.message || 'Error desconocido'}`);
    }
    
    const data = await response.json();
    
    // Extraer transcripción del resultado
    let transcript = '';
    if (data.candidates && data.candidates.length > 0 && 
        data.candidates[0].content && 
        data.candidates[0].content.parts && 
        data.candidates[0].content.parts.length > 0) {
      transcript = data.candidates[0].content.parts[0].text || '';
    }
    
    console.log(`Transcripción completada: "${transcript.substring(0, 50)}${transcript.length > 50 ? '...' : ''}"`);
    
    return new Response(
      JSON.stringify({
        success: true,
        transcript,
        call_id
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error en transcripción de audio:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Error en transcripción de audio'
      }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
