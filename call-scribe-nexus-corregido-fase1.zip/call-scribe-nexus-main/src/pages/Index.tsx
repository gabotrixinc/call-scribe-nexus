
import React from 'react';
import Dashboard from './Dashboard';

const Index: React.FC = () => {
  return <Dashboard />;
};

export default Index;
